Installation:

1. Upload all files from distribution archive to your server
2. Use index.php (open it in your browser) to generate Popup Window code